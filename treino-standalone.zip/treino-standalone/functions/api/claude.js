// Cloudflare Pages Function — rota: /api/claude
// A chave da Anthropic fica na variável de ambiente ANTHROPIC_API_KEY,
// configurada no painel do Cloudflare. Ela nunca chega ao navegador.

const MODEL = 'claude-sonnet-5';
const MAX_PROMPT = 8000;

export async function onRequestPost(context) {
  const { request, env } = context;

  const json = (obj, status = 200) =>
    new Response(JSON.stringify(obj), {
      status,
      headers: { 'content-type': 'application/json; charset=utf-8' }
    });

  if (!env.ANTHROPIC_API_KEY) {
    return json({ error: 'ANTHROPIC_API_KEY nao configurada no ambiente' }, 500);
  }

  let body;
  try {
    body = await request.json();
  } catch (e) {
    return json({ error: 'corpo invalido' }, 400);
  }

  // usado pelo app so para checar se o backend esta de pe
  if (body.ping) return json({ ok: true });

  const prompt = typeof body.prompt === 'string' ? body.prompt.trim() : '';
  if (!prompt) return json({ error: 'prompt ausente' }, 400);
  if (prompt.length > MAX_PROMPT) return json({ error: 'prompt longo demais' }, 413);

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: env.CLAUDE_MODEL || MODEL,
        max_tokens: 1000,
        messages: [{ role: 'user', content: prompt }]
      })
    });

    const data = await res.json();
    if (!res.ok) {
      return json({ error: (data && data.error && data.error.message) || 'falha na API' }, res.status);
    }
    return json({ content: data.content });
  } catch (e) {
    return json({ error: 'falha ao contatar a API' }, 502);
  }
}

// Requisicoes que nao sejam POST
export async function onRequest(context) {
  if (context.request.method === 'POST') return onRequestPost(context);
  return new Response('Use POST', { status: 405 });
}
