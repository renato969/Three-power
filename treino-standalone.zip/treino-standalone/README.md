# Treino Diário — Três Poderes (versão standalone)

Versão completa para hospedar no seu próprio domínio. Mantém tudo: cronômetro, avaliação por IA, seleção adaptativa, geração de questões novas, ranking, dashboard fixo e controle de sessão.

## O que mudou em relação à versão que roda dentro do Claude

- **Progresso** agora fica no `localStorage` do navegador, com botões de exportar e importar backup.
- **Avaliação por IA** passa por um endpoint próprio (`/api/claude`), para que a chave da Anthropic fique no servidor e nunca apareça no código da página.
- Se o endpoint estiver fora do ar, o app continua funcionando: múltipla escolha corrige sozinha e resposta livre cai na avaliação manual. O selo no topo mostra o estado ("IA ativa" ou "IA off").

## Arquivos

```
index.html                      o app inteiro
functions/api/claude.js         função serverless (Cloudflare Pages)
netlify/functions/claude.js     função serverless (Netlify)
_redirects                      mapeia /api/claude no Netlify
```

Use o par que corresponde ao seu host. Deixar os dois no repositório não causa problema.

---

## Deploy no Cloudflare Pages (recomendado)

Banda ilimitada no plano gratuito e uso comercial permitido.

1. Suba esta pasta para um repositório no GitHub.
2. Em `pages.cloudflare.com`, clique em **Create a project** e conecte o repositório.
3. Framework preset: **None**. Build command: deixe vazio. Output directory: `/`.
4. Depois do primeiro deploy, vá em **Settings → Environment variables** e adicione:
   - `ANTHROPIC_API_KEY` = sua chave, criada em `console.anthropic.com`
   - `CLAUDE_MODEL` = `claude-sonnet-5` (opcional; use `claude-haiku-4-5-20251001` para gastar menos)
5. Refaça o deploy para a variável valer.

## Deploy no Netlify

Se preferir voltar o time HouseX para o plano Starter gratuito, funciona igual.

1. Suba a pasta para o GitHub e conecte em **Add new project**.
2. Build command vazio, publish directory `.`
3. Em **Site configuration → Environment variables**, adicione `ANTHROPIC_API_KEY`.
4. Redeploy.

## Sem backend

Dá para abrir o `index.html` direto no navegador ou publicar só ele no GitHub Pages. Tudo funciona, exceto a correção automática das respostas livres e a geração de questões novas, que precisam da API.

---

## Custo

A avaliação de cada resposta livre é uma chamada curta. Com uso diário de um exercício, o gasto mensal fica em centavos. A geração de questões novas só acontece quando você esgota o banco.

## Backup

Aba **Progresso → Diagnóstico → Backup do progresso**. Exporte um JSON de vez em quando. Para migrar de aparelho, exporte em um e importe no outro.
